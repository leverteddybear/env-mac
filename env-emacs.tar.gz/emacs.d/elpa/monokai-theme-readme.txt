A port of the popular Textmate theme Monokai for Emacs 24, built on top
of the new built-in theme support in Emacs 24.
