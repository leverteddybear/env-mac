#!/bin/sh

# clean tags and cscope files
function clean() {
    result=$(find `pwd` -type f -name "*.swp" -o -name "cscope*" -o -name "tags" -o -name "filenametags")
    if [[ $result != "" ]] ; then
        for line in $result
        do
            echo $line  |xargs rm
        done
    fi
}

function build_cscope() {
    if [[ $# > 2 && $2 == "add" ]] ; then
        echo $PWD/$3 >> $CSCOPE_DIR/cscope.files
    else
        result=$(find `pwd` -type f -name "cscope*")
        if [[ $result != "" ]] ; then
            for line in $result
            do
                echo $line |xargs rm
            done
        fi
        find `pwd` -name "*.[ch]" > cscope.files
    fi
    cscope -bqk -i cscope.files
    export CSCOPE_DB=$PWD/cscope.out
    export CSCOPE_DIR=$PWD
    echo "create cscope $CSCOPE_DB"
}

function build_tags() {
    result=$(find `pwd` -type f -name "tags")
    if [[ $result != "" ]] ; then
        for line in $result
        do
            echo $line |xargs rm
        done
    fi
    # ctags --list-kinds show ctags support kinds
    if [[ $2 == "c++" ]]; then
        ctags -R --c++-kinds=+cdefgmnstuv --fields=+iaS --extra=+q --exclude=.git .
    else
        echo "normal"
        # show function signature, other option is aiKSZ
        #ctags -R --c-kinds=+p --fields=+aS --extra=+q .
        ctags -R .
    fi
    export TAG_DB=$PWD/tags
    echo "create tags success $TAG_DB"
}

# generate tag file for lookupfile plugin
function build_lookupfiles() {
    result=$(find `pwd` -type f -o -name "filenametags" -print)
    if [[ $result != "" ]] ; then
        for line in $result
        do
            echo $line |xargs rm
        done
    fi
    echo -e "!_TAG_FILE_SORTED\t2\t/2=foldcase/" > filenametags
    find `pwd` -type d \( -path `pwd`/.metadata -o -path `pwd`/Debug \) -prune -o \
        -not -regex '.*\.\(png\|gif\|o\|d\|swo\)' -type f -printf "%f\t%p\t1\n" | \
        sort -f >> filenametags
    export FileNameTags_DB=$PWD/filenametags
    echo "create lookupfile $FileNameTags_DB"
}

# shell entry point
option=$1

case $option in
    "all")
        build_tags
        build_cscope
        build_lookupfiles
        ;;
    "cscope")
        build_cscope $*
        ;;
    "tags")
        build_tags $*
        ;;
    "lookupfile")
        build_lookupfiles
        ;;
    "set")
        export FileNameTags_DB=$PWD/filenametags
        export CSCOPE_DB=$PWD/cscope.out
        export TAG_DB=$PWD/tags
        ;;
    "clean")
        clean
        ;;
    "help")
        echo "################################################"
        echo "cmd: cscope, tags, lookupfile, settags, clean"
        echo "################################################"
        ;;
esac
